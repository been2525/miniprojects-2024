﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace teamproject4.Helpers
{
    class Common
    {
        public static readonly string CONNSTRING = "Data Source=localhost;Initial Catalog=smart_factory;Persist Security Info=True;User ID=sa;Encrypt=True;Trust Server Certificate=True" +
                                                   "Password = mssql_p@ss";
    }
}
